var firebaseConfig = {
  apiKey: "AIzaSyBeUPzjI7PvpPz90Sf-GPIfvheHgY0FviU",
authDomain: "bygone-1000.firebaseapp.com",
projectId: "bygone-1000",
storageBucket: "bygone-1000.appspot.com",
messagingSenderId: "408028574867",
appId: "1:408028574867:web:8c5c19e69a348b3cc40966",
measurementId: "G-RNQDL3CQEF"
};
// Initialize Firebase
firebase.initializeApp(firebaseConfig);
firebase.analytics();
