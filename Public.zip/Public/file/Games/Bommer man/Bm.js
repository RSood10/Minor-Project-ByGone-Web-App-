/*
var Rect = function(x, y, w, h){
	this.x = x;
	this.y = y;
	this.w = w;
	this.h = h;
	this.containsPoint = function(rect, point){
		if(rect.x < point.x && rect.y < point.y && rect.x + rect.w > point.x && rect.y + rect.h > point.y) return true;
		return false;
	}
}
*/

var tile;

Array.prototype.remove = function(from, to) {
  var rest = this.slice((to || from) + 1 || this.length);
  this.length = from < 0 ? this.length + from : from;
  return this.push.apply(this, rest);
};

var Player = function(x, y, remote){
	this.color = "rgb(255,255,255)"
	this.x = x;
	this.y = y;
	this.px = 0;
	this.py = 0;
	this.id = Math.round(new Date().getTime() * Math.random());
	this.alive = true;
	this.bombs_on_field = 0;
	this.bombs_on_field_max = 1;
	this.bombs_radius = 3;
	this.speed = 2;
	this.direction = "n";
	this.die = function(){
		this.alive = false;
		alert("You are dead!");
	}
	this.checkValues = function(){
		if(this.speed > 5) this.speed = 5;
		if(this.bombs_on_field_max > 8) this.bombs_on_field_max = 8;
		if(this.bombs_radius > 10) this.bombs_radius = 10;
	}
	this.containsPoint = function(rect, x, y, offset){
		var o = (offset) ? offset : 0;
		if(rect.x - o <= x && rect.y - o <= y && rect.x + rect.w + o >= x && rect.y + rect.h + o >= y) return true;
		return false;
	}
	this.layBomb = function(game){
		game.playSFX("lay_bomb");
		if(game.map[this.y][this.x] == 0 && this.bombs_on_field < this.bombs_on_field_max) game.addBomb(this.x, this.y, 80);
	}
	this.go = function(direction, game){
		var center_x = Math.round(this.px + game.cell_pw / 2);
		var center_y = Math.round(this.py + game.cell_ph / 2);
		var available_directions  = { n:true, e:true, s:true, w:true };
		for(var y = 0; y < game.h; y++){
			for(var x = 0; x < game.w; x++){
				if(game.map[y][x] != 0){
					var rect = { x : x*game.cell_pw, y : y*game.cell_ph, w : game.cell_pw, h : game.cell_ph };
					if(this.containsPoint(rect, center_x, center_y - this.speed, 3)) available_directions.n = false;
					if(this.containsPoint(rect, center_x + this.speed, center_y, 3)) available_directions.e = false;
					if(this.containsPoint(rect, center_x, center_y + this.speed, 3)) available_directions.s = false;
					if(this.containsPoint(rect, center_x - this.speed, center_y, 3)) available_directions.w = false;
				}
			}
		}
		this.direction = direction;
		switch(direction){
			case "n":
				if(available_directions.n) this.py-=this.speed;
			break;
			case "e":
				if(available_directions.e) this.px+=this.speed;
			break;
			case "s":
				if(available_directions.s) this.py+=this.speed;
			break;
			case "w":
				if(available_directions.w) this.px-=this.speed;
			break;
		}
	}
}

var Game = function(canvas_el, websocket, images) {
	this.cnv = canvas_el;
	this.ctx = this.cnv.getContext("2d");
	this.ph = this.cnv.height;
	this.pw = this.cnv.width;
	this.player = new Player(1, 1);
	this.pressed_keys = {};
	this.frame = 0;
	this.ws = websocket;
	this.images = images;
	this.tracks = {};
	this.last_remote_obj;
	this.explosions = [];
	this.bombs = [];
	this.items = [];
	this.remote_players = {};
	/*
	this.ws.parent = this;
	this.ws.onmessage = function (evt) {
		var d = JSON.parse(evt.data);
		this.parent.remote_players[d.player.id] = d.player;
	};
	*/
	this.addBomb = function(x, y, time){
		for(var i in this.bombs){
			if(this.bombs[i].x == x && this.bombs[i].y == y) return false;
		}
		this.bombs.push({ x:x, y:y, t:time, passable:true });
		this.player.bombs_on_field++;

	}
	this.addItem = function(x, y){
		for(var i in this.items){
			if(this.items[i].x == x && this.items[i].y == y) return false;
		}
		var val;
		if(Math.random() > .7){
			switch(Math.round(Math.random()*2)){
				case 0:
					val = "speed";
				break;
				case 1:
					val = "bombs_on_field_max";
				break;
				case 2:
					val = "bombs_radius";
				break;
			}
			this.items.push({ x:x, y:y, v:val });
		}
	}
	this.explode = function(bomb){
		this.playSFX("boom");
		var explosion = {
			n:[],
			e:[],
			s:[],
			w:[],
			t:25
		};
		//explosion.push({ x:bomb.x, y:bomb.y });
		for(var i=0; i<this.player.bombs_radius; i++){
			explosion.n.push({ x:bomb.x, y:bomb.y-i });
			explosion.e.push({ x:bomb.x+i, y:bomb.y });
			explosion.s.push({ x:bomb.x, y:bomb.y+i });
			explosion.w.push({ x:bomb.x-i, y:bomb.y });
		}
		this.explosions.push(explosion);
	}
	this.load = function(map){
		this.map = map;
		this.h = this.map.length;
		this.w = this.map[0].length;
		this.cell_ph = this.ph / this.h;
		this.cell_pw = this.pw / this.w;
		this.player.px = this.player.x * this.cell_pw;
		this.player.py = this.player.y * this.cell_ph;
	};
	this.playSFX = function(sound){
		//num = Math.round(Math.random()*5);
		//this.tracks[num] = new Audio(sound+".wav");
		//this.tracks[num].play();
		//new Audio(sound+".wav").play();
		//this.audio.src = sound+".wav";
		//this.audio.play();
    if(!this.tracks[sound]) this.tracks[sound] = new Audio("http://saibotd.com/"+sound+".wav");
		this.tracks[sound].play();
	},
	this.enterFrame = function(){
		this.ctx.clearRect(0,0,this.cnv.width,this.cnv.height);
		if(this.player.alive){
			if(this.pressed_keys[37]) this.player.go("w", this);
			if(this.pressed_keys[38]) this.player.go("n", this);
			if(this.pressed_keys[39]) this.player.go("e", this);
			if(this.pressed_keys[40]) this.player.go("s", this);
			if(this.pressed_keys[32]) this.player.layBomb(this);
			this.player.x = Math.round((this.player.px)  / this.cell_pw);
			this.player.y = Math.round((this.player.py) / this.cell_ph);
		}
		for(var i in this.bombs){
			if(this.bombs[i].t == 0){
				this.explode(this.bombs[i]);
				this.map[this.bombs[i].y][this.bombs[i].x] = 0;
				this.bombs.remove(i);
				this.player.bombs_on_field--;
			}
		}
		for(var i in this.explosions){
			if(this.explosions[i].t == 0) this.explosions.remove(i);
		}
		for(var y = 0; y < this.h; y++){
			for(var x = 0; x < this.w; x++){
				switch(this.map[y][x]){
					case 1:
						this.ctx.fillStyle = "rgb(29,117,59)";
						//this.ctx.fillRect (x*this.cell_pw, y*this.cell_ph, this.cell_pw, this.cell_ph);
						this.ctx.drawImage(this.images.tile2, x*this.cell_pw, y*this.cell_ph);
					break;
					case 2:
						this.ctx.fillStyle = "rgb(8,33,17)";
						this.ctx.fillRect (x*this.cell_pw, y*this.cell_ph, this.cell_pw, this.cell_ph);
					break;
					default:
						//this.ctx.fillStyle = "rgb(50,50,50)";
						this.ctx.drawImage(this.images.tile, x*this.cell_pw, y*this.cell_ph);
				}
			}
		}
		for(var i in this.bombs){
			if(this.bombs[i].t > 0) {
				this.ctx.fillStyle = "rgb("+this.bombs[i].t+","+this.bombs[i].t+","+this.bombs[i].t+")";
				this.bombs[i].t--;
				if(this.bombs[i].passable){
					var center_x = Math.round(this.player.px + this.cell_pw / 2);
					var center_y = Math.round(this.player.py + this.cell_ph / 2);
					this.map[this.bombs[i].y][this.bombs[i].x] = 0;
					if(!this.player.containsPoint({ x : this.bombs[i].x*this.cell_pw, y : this.bombs[i].y*this.cell_ph, w : this.cell_pw, h : this.cell_ph }, center_x, center_y, 8)){
						this.bombs[i].passable = false;
					}
				}
				else this.map[this.bombs[i].y][this.bombs[i].x] = 3;
				//this.ctx.fillRect (this.bombs[i].x*this.cell_pw, this.bombs[i].y*this.cell_ph, this.cell_pw, this.cell_ph);
				this.ctx.beginPath();
				this.ctx.arc(this.bombs[i].x*this.cell_pw + this.cell_pw/2, this.bombs[i].y*this.cell_ph + this.cell_ph/2, this.cell_pw/2, 0, Math.PI*2, true);
				this.ctx.closePath();
				this.ctx.fill();
			}
		}
		for(var i in this.items){
			switch(this.items[i].v){
				case "bombs_on_field_max":
					this.ctx.fillStyle = "rgb(0,200,0)";
					this.ctx.fillRect (this.items[i].x*this.cell_pw, this.items[i].y*this.cell_ph, this.cell_pw, this.cell_ph);
				break;
				case "speed":
					this.ctx.fillStyle = "rgb(200,200,0)";
					this.ctx.fillRect (this.items[i].x*this.cell_pw, this.items[i].y*this.cell_ph, this.cell_pw, this.cell_ph);
				break;
				case "bombs_radius":
					this.ctx.fillStyle = "rgb(0,200,200)";
					this.ctx.fillRect (this.items[i].x*this.cell_pw, this.items[i].y*this.cell_ph, this.cell_pw, this.cell_ph);
				break;
			}
			if(this.items[i].x == this.player.x && this.items[i].y == this.player.y){
				this.player[this.items[i].v]++;
				this.player.checkValues();
				this.items.remove(i);
			}
		}
		this.ctx.fillStyle = "rgb(255,0,0)";
		for(var i in this.explosions){
			this.explosions[i].t--;
			directions:
			for(dir in this.explosions[i]) {
				for(var ii in this.explosions[i][dir]) {
					if(this.explosions[i].t > 0) {
						var tile = this.getMapTile(this.explosions[i][dir][ii].x, this.explosions[i][dir][ii].y);
						if(tile !== false){
							if(tile == 3) {
								for(var b in this.bombs){
									if(this.bombs[b].y == this.explosions[i][dir][ii].y && this.bombs[b].x == this.explosions[i][dir][ii].x) this.bombs[b].t = 1;
								}
							}
							var _break = false;
							switch(tile){
								case 0:
									if(this.player.x == this.explosions[i][dir][ii].x && this.player.y == this.explosions[i][dir][ii].y && this.player.alive) this.player.die();
									this.ctx.fillRect (this.explosions[i][dir][ii].x*this.cell_pw, this.explosions[i][dir][ii].y*this.cell_ph, this.cell_pw, this.cell_ph);
								break;
								case 1:
									this.map[this.explosions[i][dir][ii].y][this.explosions[i][dir][ii].x] = 0;
									this.addItem(this.explosions[i][dir][ii].x, this.explosions[i][dir][ii].y);
									this.ctx.fillRect (this.explosions[i][dir][ii].x*this.cell_pw, this.explosions[i][dir][ii].y*this.cell_ph, this.cell_pw, this.cell_ph);
									this.explosions[i][dir].remove(ii, 10);
									_break = true;
								break;
								case 3:
								case 2:
									this.explosions[i][dir].remove(ii, 10);
									_break = true;
								break;
							}
							if(_break) break directions;
						}
					}
				}
			}
		}
		//this.ctx.fillStyle = "rgb(20,20,0)";
		//this.ctx.fillRect (this.player.x*this.cell_pw, this.player.y*this.cell_ph, this.cell_pw, this.cell_ph);
		for(id in this.remote_players){
			this.ctx.fillStyle = "rgb(20,20,0)";
			this.ctx.fillRect ((this.remote_players[id].px)+2, (this.remote_players[id].py)+2, this.cell_pw-4, this.cell_ph-4);
		}

		this.ctx.fillStyle = this.player.color;
		this.ctx.fillRect ((this.player.px)+2, (this.player.py)+2, this.cell_pw-4, this.cell_ph-4);

		var remote_obj = { player:this.player };
		if(this.last_remote_obj !== remote_obj) {
			//this.ws.send(JSON.stringify(remote_obj));
			this.last_remote_obj = remote_obj;
		}

		this.frame++;
	};
	this.getMapTile = function(x,y){
		if(y > 0 && y < this.map.length - 1 && x > 0 && x < this.map[0].length - 1) return this.map[y][x];
		return false;
	}
	this.keyHandler = function(e){
		if(e.keyCode == 32 || e.keyCode == 37 || e.keyCode == 38 || e.keyCode == 39 || e.keyCode == 40){
			if(e.type == "keydown"){
				this.pressed_keys[e.keyCode] = true;
			} else if (e.type == "keyup"){
				this.pressed_keys[e.keyCode] = false;
			}
		}
	}
}



function go(){
	var map = [
	[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2],
	[2,0,0,0,1,1,1,1,1,1,1,1,1,1,2],
	[2,0,2,1,2,1,2,1,2,1,2,1,2,1,2],
	[2,0,1,1,1,1,1,1,1,1,1,1,1,1,2],
	[2,1,2,1,2,1,2,1,2,1,2,1,2,1,2],
	[2,1,1,1,1,1,1,1,1,1,1,1,1,1,2],
	[2,1,2,1,2,1,2,1,2,1,2,1,2,1,2],
	[2,1,1,1,1,1,1,1,1,1,1,1,1,1,2],
	[2,1,2,1,2,1,2,1,2,1,2,1,2,1,2],
	[2,1,1,1,1,1,1,1,1,1,1,1,1,1,2],
	[2,1,2,1,2,1,2,1,2,1,2,1,2,1,2],
	[2,1,1,1,1,1,1,1,1,1,1,1,1,1,2],
	[2,1,2,1,2,1,2,1,2,1,2,1,2,1,2],
	[2,1,1,1,1,1,1,1,1,1,1,1,1,1,2],
	[2,2,2,2,2,2,2,2,2,2,2,2,2,2,2]
	];
	/*
	var ws = new WebSocket("ws://saibotd.com:8080");
	ws.onclose = function() { };
	ws.onopen = function() {*/
		tile = new Image();
		tile2 = new Image();
		tile.onload = function(){
			var game = new Game(document.getElementById("_game"), null, {tile:tile, tile2:tile2});
			game.load(map);
			document.onkeydown = document.onkeyup = function(e){ game.keyHandler(e); }
			var enterframe = window.setInterval(function(){ game.enterFrame() }, 40);
		}
    tile.src = "http://saibotd.com/tile.gif";
		tile2.src = "http://saibotd.com/tile2.gif";
/*	};*/


}

go();
